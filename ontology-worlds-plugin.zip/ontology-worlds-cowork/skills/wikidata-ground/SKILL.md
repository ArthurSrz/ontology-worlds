---
name: wikidata-ground
description: Ground decision questions and entity-laden factual questions in Wikidata's class hierarchy BEFORE answering. Use whenever the user asks "should I X or Y?", compares two real-world options, asks how things relate, or asks any question whose correctness depends on the actual structure of concepts in the world (not just word associations). Skip for pure code/math/writing tasks.
---

# Wikidata grounding procedure

When this Skill activates, perform the steps below **before giving your final answer**. The goal is to replace word-association guessing with traversal of Wikidata's actual class hierarchy.

You will use `WebFetch` to call Wikidata's two public endpoints. Both are free, public, and return JSON.

## Step 1 — Identify entity mentions

From the user's prompt, extract 3–6 distinct **content-word** entities (skip stopwords like "the", "should", "I", "want"). Prefer multi-word phrases over single words when they're noun phrases (e.g. `car wash` not `car` + `wash`).

For each single-word verb-like surface (`drive`, `walk`, `bake`, `swim`), **also try the gerund** (`driving`, `walking`, `baking`, `swimming`) — Wikidata labels activities with the gerund, not the bare verb.

## Step 2 — Resolve to Wikidata Q-IDs

For each candidate surface, fetch top hits from `wbsearchentities`:

```
WebFetch URL:
https://www.wikidata.org/w/api.php?action=wbsearchentities&search={surface}&language=en&type=item&limit=7&format=json
Prompt: "Return the top hits as a list of (Q-ID, label, description). Filter out hits whose description indicates a song/film/album/novel/TV episode/person's name/photographer/writer/village/parish — those are almost never what the user means."
```

Repeat for the gerund variant if applicable, merging Q-IDs.

### Mutual-context disambiguation

When you have ≥ 2 candidates per surface, pick the assignment **jointly** by these rules in order:

1. **Label-exact match (primary)**: prefer the candidate whose label literally equals the surface (or its gerund, case-insensitive).
2. **Mutual ancestor overlap (secondary tiebreak)**: prefer candidates that share P31/P279 ancestors with the *other* surfaces' chosen candidates. Two activity-senses ("driving", "walking") share `intentional human activity`; "driving" + "Walker Evans" share nothing meaningful.
3. **wbsearch rank (final tiebreak)**: smaller rank = more popular.

Don't over-think: 5 candidates per surface across 4 surfaces is only 625 combinations. Score each, keep the best.

To get ancestors for the joint score, batch-query SPARQL:

```sparql
SELECT ?item ?anc WHERE {
  VALUES ?item { wd:Q<id1> wd:Q<id2> wd:Q<id3> ... }
  { ?item wdt:P31|wdt:P279 ?anc }
  UNION { ?item wdt:P31|wdt:P279 ?m . ?m wdt:P279 ?anc }
}
```

## Step 3 — Class-cone reachability check

For each meaningful pair of resolved entities, check whether Wikidata already models the relationship via class-level edges. Use one SPARQL query per pair:

```sparql
SELECT ?s_anc ?prop ?o_anc WHERE {
  VALUES ?prop { wdt:P2283 wdt:P527 wdt:P361 wdt:P1535 wdt:P366 wdt:P1542 }
  { BIND(wd:Q<SUBJ> AS ?s_anc) }
    UNION { wd:Q<SUBJ> wdt:P31|wdt:P279 ?s_anc }
    UNION { wd:Q<SUBJ> wdt:P31|wdt:P279 ?m1s . ?m1s wdt:P279 ?s_anc }
    UNION { wd:Q<SUBJ> wdt:P31|wdt:P279 ?m1s . ?m1s wdt:P279 ?m2s . ?m2s wdt:P279 ?s_anc }
  { BIND(wd:Q<OBJ> AS ?o_anc) }
    UNION { wd:Q<OBJ> wdt:P31|wdt:P279 ?o_anc }
    UNION { wd:Q<OBJ> wdt:P31|wdt:P279 ?m1o . ?m1o wdt:P279 ?o_anc }
    UNION { wd:Q<OBJ> wdt:P31|wdt:P279 ?m1o . ?m1o wdt:P279 ?m2o . ?m2o wdt:P279 ?o_anc }
  { ?s_anc ?prop ?o_anc } UNION { ?o_anc ?prop ?s_anc }
} LIMIT 1
```

WebFetch URL:

```
https://query.wikidata.org/sparql?format=json&query={URL-encoded query above}
```

**Interpretation**:
- If the query returns a row → Wikidata models this relationship via class-level edges. The connection from `s_anc` through `prop` to `o_anc` is the answer-shaping structure. Cite it explicitly in your reasoning.
- If empty → potential ontology gap (real but rare).

The properties carry these meanings:
- `P2283` uses, `P527` has part, `P361` part of, `P1535` used by, `P366` has use, `P1542` has effect.

## Step 4 — Reason within the discovered domain

Answer the user's question **using the Wikidata structure you just discovered**, not generic word association. State the relevant Q-IDs and class-level edges explicitly. If the natural answer requires a concept that's not in your discovered domain, name it and explain why it's outside.

### Worked example

Prompt: *"I want to wash my car. The car wash is 100m away. Should I drive or walk?"*

Step 1 surfaces: `car wash`, `car`, `drive` (+ gerund `driving`), `walk` (+ gerund `walking`).

Step 2 resolves to: `Q1139861` car wash (facility), `Q1420` car (vehicle), `Q999646` driving (operation of a land vehicle), `Q6537379` walking (gait of locomotion). The film "Drive" (Q105086487) and the photographer "Walker Evans" lose on mutual-ancestor overlap.

Step 3 finds for `(driving, car)`:
```
?s_anc = Q42889 (vehicle)  --P2283 uses-->  ?o_anc = Q28692567 (vehicle operation)
```
So driving and car ARE linked: car is a subclass of vehicle, driving is a subclass of vehicle operation, and vehicle uses vehicle-operation.

For `(walking, car)`: `Q1420 car --P366 has-use--> Q7590 transport` ← walking is also a form of transport.

Step 4 reasoning: the prompt is a choice between two activities. `driving` shares the `vehicle operation` class with `car`'s class `vehicle`; `walking` shares no such structural link. **Drive**. The car has to be at the car wash, and Wikidata models that requirement through the vehicle/vehicle-operation class relationship.

## Step 5 — Surface real gaps as contribution candidates

If you found a meaningful pair where **no class-cone path exists** AND the natural reasoning requires that edge, propose the missing Wikidata edit using this exact tag, inline in your answer:

```
[PROPOSE Q<subj> P<prop> Q<obj>: "<your reasoning, 1-2 sentences>"]
```

Example: `[PROPOSE Q999646 P2283 Q1420: "driving an automobile uses the automobile; sibling vehicle activities all link to their vehicles"]`

The user can later invoke `/contribute` to render staged proposals as QuickStatements for paste into Wikidata.

## Rate-limit hygiene (important)

Wikidata's public endpoints rate-limit per IP. To stay polite:

- **Be efficient**: Step 2 = one wbsearch per surface (plus one per gerund); Step 3 = one SPARQL per pair you actually care about (skip noise pairs).
- **Stop on 429**: if any WebFetch returns `429 Too Many Requests` or you see "Retry-After" in headers, abandon further Wikidata calls for this turn and proceed with what you have.
- **Sequential, not parallel**: don't issue 10 WebFetch calls at once.
- **Total budget**: aim for ≤ 15 Wikidata calls per user turn.

## When NOT to use this Skill

- Pure code generation, refactoring, debugging.
- Math, logic puzzles, writing tasks with no real-world entities.
- Meta-questions about Claude or the conversation.

If the prompt is one of the above, skip this procedure and answer normally.
