# ontology-worlds (Cowork edition)

Wikidata-grounded reasoning for Claude Code in Cowork.

## How it works

This version of the plugin works **entirely through a Skill plus slash
commands** — no Python, no hooks, no local shell. Claude itself does the
Wikidata lookups via `WebFetch`.

### Skill — `wikidata-ground`

Auto-activates on decision questions ("should I X or Y?"), entity
comparison questions, and any real-world factual question whose answer
depends on how concepts actually relate. Procedure:

1. Extract entity mentions from the prompt (with verb→gerund augmentation).
2. Resolve them to Wikidata Q-IDs via `wbsearchentities`.
3. **Mutual-context disambiguation**: when multiple candidates exist per
   surface, pick the joint assignment that maximises label-exact-matches
   then shared-ancestor overlap. Two activity senses cluster together;
   films and people lose.
4. **Class-cone reachability**: for each pair of resolved seeds, walk up
   the P31/P279 hierarchy from both sides (depth ≤ 3) and check whether
   any pair of ancestors is connected by a domain-defining property in
   either direction. Reachable → Wikidata models it. Not reachable AND
   reasoning depends on it → real ontology gap.
5. Answer using the discovered structure. Surface gaps as
   `[PROPOSE Q… P… Q…: "..."]` tags inline.

### Slash commands

- `/ground <question>` — force the Skill on any prompt.
- `/world` — show the JIT domain built for the last grounded answer.
- `/gaps` — list detected Wikidata gaps + their debate questions.
- `/contribute` — render staged `[PROPOSE …]` tags as QuickStatements.

## Why this is the Cowork edition

Cowork (web Claude Code) doesn't execute `"type": "command"` plugin hooks
— those require local shell. The v0.3 CLI edition uses Python hooks for
deterministic SPARQL pipelines; this Cowork edition delegates the same
procedure to Claude itself via Skill instructions and WebFetch.

Trade-off: less deterministic (Claude does the SPARQL instead of code),
no joint-optimisation guarantees on the disambiguator. But it actually
runs in Cowork.

## Rate-limit hygiene

Wikidata's endpoints rate-limit per IP. The Skill instructs Claude to:
- Issue ≤ 15 Wikidata calls per turn.
- Stop immediately on HTTP 429 / `Retry-After`.
- Sequential calls only (no parallel bursts).

Repo: https://github.com/ArthurSrz/ontology-worlds
