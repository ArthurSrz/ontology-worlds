---
description: Render staged Wikidata contribution proposals as QuickStatements
---

# /contribute — turn staged proposals into a Wikidata edit batch

Scan your recent conversation context for `[PROPOSE Q… P… Q…: "…"]` tags you emitted during the session. For each one, render a row in a table:

| Subject (Q-id) | Property (P-id) | Object (Q-id) | Reasoning |
|---|---|---|---|

Then render a **QuickStatements v1** block (fenced ```code``` so it copy-pastes cleanly), one line per proposal:

```
Q190984|P2283|Q1420|S887|"you drive a car"
Q193599|P2283|Q1420|S887|"car wash uses car"
```

Tell the user they can paste this at <https://quickstatements.toolforge.org/> to publish their proposed Wikidata edits.

After the batch, ask:

- Want to **drop** any proposal? (specify by row)
- Want to **edit** the reasoning of any proposal?
- Or **publish as-is**?

Do NOT POST to Wikidata directly — direct API write (`wbeditentity` + OAuth) is out of scope. The user reviews and pastes themselves.

If no `[PROPOSE …]` tags appeared in this session, say so: "No Wikidata contributions staged yet — when I find a real ontology gap during grounded reasoning, I'll emit a PROPOSE tag and you can come back here."
