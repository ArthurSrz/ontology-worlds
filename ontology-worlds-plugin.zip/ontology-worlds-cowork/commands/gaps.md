---
description: List Wikidata gaps you detected in this session and their debate questions
---

# /gaps — surface candidate Wikidata edits

From your recent conversation context, list every Wikidata gap you surfaced. A gap is a pair (subject, object) where **no class-cone path exists** in Wikidata (step 3 of `wikidata-ground` returned empty) AND the natural reasoning requires the edge.

For each gap, render:

- **`<subject_label>` — *<suggested_property_label>* (<P-id>) → `<object_label>`**
- *Why it matters:* the role the missing edge played in answering the user.
- *Evidence:* sibling entities that DO have this edge (if you checked).
- *To stage as a Wikidata contribution:* the exact `[PROPOSE Q… P… Q…: "…"]` tag.

If no gaps came up this session, say so explicitly — that's often correct: Wikidata covers most everyday domains via class-level edges. Suggest the user try a sparser-coverage prompt (recent science, niche craft, emerging cultural concept).
