---
description: Show the JIT Wikidata domain you built for the most recent question
---

# /world — display the last grounded domain

From your recent conversation context, render the JIT Wikidata domain you built for the most recent grounded answer:

1. **Seeds.** The entity mentions you extracted and the Q-IDs you resolved them to (with labels and confidence rationale).
2. **Class hierarchy.** For each seed, the P31 (instance-of) and P279 (subclass-of) ancestors up to 3 hops — i.e. the "class cone" you traversed.
3. **Cross-cone edges.** The class-cone reachability paths you found (e.g. `vehicle --uses--> vehicle operation`).
4. **Out-of-domain mentions.** Any entities you mentioned in your answer that weren't in the discovered domain.

If you haven't grounded anything in this session yet, say so and suggest the user run `/ground <question>` or just ask a real-world question.

Do not re-run the SPARQL queries — just reproduce what you already discovered from the prior turn.
