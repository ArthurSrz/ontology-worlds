---
description: Explicitly ground the next answer in Wikidata's class hierarchy (forces wikidata-ground Skill)
---

# /ground — force Wikidata grounding

The user may invoke `/ground <question>` to explicitly request Wikidata-grounded reasoning, even if the question wouldn't normally trigger the `wikidata-ground` Skill on its own.

When this command fires:

1. Load and follow the `wikidata-ground` Skill's procedure end-to-end on the user's question.
2. Show your work: list the resolved Q-IDs, the SPARQL queries you ran, and the class-cone paths (or gaps) you found.
3. Then give your grounded answer.

If `/ground` is invoked without a question, ask the user what they want grounded.
